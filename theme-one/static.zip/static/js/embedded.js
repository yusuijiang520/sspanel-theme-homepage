var scripts = document.getElementsByTagName("script");
var scriptSrcRegex = new RegExp("https://jinshuju.net/f/5b61b62d3965652f2d079770/embedded|https://jinshuju.net/f/fUyJsJ/embedded|https://jinshuju.net/f/5b61b62d3965652f2d079770/embedded|https://jinshuju.net/f/fUyJsJ/embedded");
var target = null;
var script;
var matchedUrl = null;
for (var i = 0; i < scripts.length; i++) {
  script = scripts[i];
  var testUrl = scriptSrcRegex.exec(script['src']);
  if (testUrl != null) {
    target = script.parentNode;
    target.removeChild(script);
    matchedUrl = testUrl[0].substring(0, testUrl[0].indexOf("/embedded"));
    break;
  }
}
if (target != null && matchedUrl != null) {
  var iframeId = 'goldendata_form_fUyJsJ';
  var resize = document.createElement('script');
  resize.type = 'text/javascript';
  script =  "window.GoldenData = {};\n" +
                "GoldenData.receiveSize = function (e) {\n" +
                "  if (('https://jinshuju.net/'.indexOf(e.origin) === 0 || 'https://jinshuju.net/'.indexOf(e.origin) === 0) && e.data.event == 'heightChanged') { \n" +
                "    document.getElementById('" + iframeId + "').style.height = e.data.value + 'px';\n" +
                "  }\n" +
                "};\n" +
                "if (window.addEventListener) {\n" +
                "  window.addEventListener('message', GoldenData.receiveSize, false);\n" +
                "} else if (window.attachEvent) {\n" +
                "  window.attachEvent('onmessage', GoldenData.receiveSize, false);\n" +
                "}";
  resize.text = script;
  target.appendChild(resize);
  target.innerHTML += "<iframe id='" + iframeId + "' src='" + matchedUrl + "?background=white&amp;banner=show&amp;embedded=true' width='100%' height='400' frameborder=0 allowTransparency='true'>";
}
